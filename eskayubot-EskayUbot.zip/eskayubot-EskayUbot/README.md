<h1 align="center" width="35px">𝗘𝗦𝗞𝗔𝗬 𝗨𝗕𝗢𝗧<width="35px"></h1>
<p align="center">
    <img alt="𝗘𝗦𝗞𝗔𝗬 𝗨𝗕𝗢𝗧" src="https://telegra.ph/file/a92718eba5d1031c36aad.jpg"/>
    <img alt="BUILD IN" src="https://img.shields.io/badge/BUILD%20-Last Day-brightgreen"/>             </p>


𝗘𝗦𝗞𝗔𝗬 𝗨𝗕𝗢𝗧 adalah userbot Telegram modular yang berjalan di Python3 dengan database sqlalchemy.

Berbasis [Paperplane](https://github.com/RaphielGang/Telegram-UserBot) dan [ProjectBish](https://github.com/adekmaulana/ProjectBish) userbot.
Saya membuat repository ini untuk memilih dan menambahkan beberapa modul yang saya butuhkan dengan banyak perubahan, fitur dan modul.

## Disclaimer

```
Saya tidak bertanggung jawab atas penyalahgunaan bot ini.
Bot ini dimaksudkan untuk bersenang-senang sekaligus membantu Anda
mengelola grup secara efisien dan mengotomatiskan beberapa hal yang membosankan.
Gunakan bot ini dengan risiko Anda sendiri, dan gunakan dengan bijak.
```
## DEPLOY TO HEROKU
 
<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/WHYFZN/CilikUserbot"> <img 
src="https://img.shields.io/badge/Deploy%20To%20Heroku-purple?style=flat&logo=heroku" width="210" height="34.45" /></a></p>

